# Kwaku Ebenezer

A simple responsive business website for Kwaku Ebenezer, built as a static web app that can be published as a live public page.

## Run locally

```bash
python -m http.server 3000
```

Then open http://localhost:3000

## Publish as a live web page

This project is set up for GitHub Pages deployment.

1. Push this repository to GitHub.
2. Open the repository on GitHub.
3. Go to Settings > Pages.
4. Under Build and deployment, choose "GitHub Actions".
5. The workflow file is already included at `.github/workflows/deploy.yml`.
6. After the workflow runs, your live URL will be:

```text
https://<your-github-username>.github.io/kwaku-ebenezer/
```

## Share the app link

Share the GitHub Pages URL with customers so they can open the site from any device. Because the page includes a web app manifest, mobile users can also install it to their home screen like an app.
